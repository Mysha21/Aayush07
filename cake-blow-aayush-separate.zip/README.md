# 🎂 Happy Birthday Aayush Web App

This is a single-tier realistic birthday cake web app with colorful candles and **Happy Birthday Aayush** text on the cake.  
Blow out the candles using your microphone or by adding candles and sharing the link!

## Usage

1. Open `index.html` in a browser (or deploy via GitHub Pages).  
2. Click **Add Candle** to add candles.  
3. Click **Generate Share Link** to share your cake with friends.  
4. Friend opens link → sees cake → blows candles with mic.

## GitHub Pages Deployment

1. Upload all files to a GitHub repository.  
2. Go to **Settings → Pages**.  
3. Branch: `main`, Folder: `/ (root)` → Save.  
4. Live link example: `https://your-username.github.io/cake-blow-aayush/`

Enjoy celebrating Aayush's birthday! 🎉